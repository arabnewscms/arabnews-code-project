<?php $__env->startSection('admin'); ?>

Welcome Admin Panel

<?php $__env->stopSection(); ?>
<?php echo $__env->make(app('at').'.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>