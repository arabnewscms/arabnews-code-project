@include(app('at').'.header')
@include(app('at').'.nav')
@include(app('at').'.errors')

@yield('admin')


@include(app('at').'.footer')