@extends(app('at').'.index')
@section('admin')

Welcome Admin Panel

@stop